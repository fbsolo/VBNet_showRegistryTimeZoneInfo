﻿Imports System.IO
Imports System.TimeZoneInfo

Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim adjustments As AdjustmentRule()
        Dim timeZoneAdjustmentString As String = ""
        Dim timeZoneString As String = ""
        Dim timeZoneAdjustmentRuleNumber As Integer

        '  In the outer For Each loop, build a
        '
        '      timeZoneString
        '
        '  string of time zone information sourced
        '  from the Windows registry. Each For Each
        '  iteration covers one time zone. Use a
        '
        '      " | "
        '
        '  delimiter between the values, because some
        '  of the returned values have embedded commas.
        '  This means that data for a CSV file would
        '  need more "cleaning". Add a newline at the
        '  end of each finished time zone. The timeZoneString
        '  variable accumulates for all detected time zones.

        For Each z As TimeZoneInfo In TimeZoneInfo.GetSystemTimeZones

            '   First, build the timeZoneString for each timeZoneInfo in TimeZoneInfo.GetSystemTimeZones

            timeZoneString += z.Id
            timeZoneString += "|"
            timeZoneString += z.StandardName
            timeZoneString += "|"
            timeZoneString += z.DisplayName
            timeZoneString += "|"
            timeZoneString += z.DaylightName
            timeZoneString += "|"
            timeZoneString += z.SupportsDaylightSavingTime.ToString
            timeZoneString += "|"
            timeZoneString += z.BaseUtcOffset.TotalSeconds.ToString
            timeZoneString += Environment.NewLine

            '   https://docs.microsoft.com/en-us/dotnet/api/system.timezoneinfo.adjustmentrule?view=netframework-4.8

            '  For this specific z (TimeZoneInfo) value,
            '  build an array of adjustments

            adjustments = z.GetAdjustmentRules()

            '  Reset the rule number for the New set of adjustment
            '  rules in the inner For Each loop.

            timeZoneAdjustmentRuleNumber = 1

            '  In the inner For Each loop, build a
            '
            '      timeZoneAdjustmentString
            '
            '  string of time zone adjustment information
            '  sourced from the Windows registry. Each For Each
            '  iteration covers one time zone adjustment.
            '  Use a
            '
            '      " | "
            '
            '  delimiter between the values, to keep it consistent
            '  with the outer loop. Future adjustments might
            '  have commas. Also, this means that data for a
            '  CSV file would need more "cleaning". Add a newline
            '  at the end of each finished time zone adjustment.
            '  The timeZoneAdjustmentString variable accumulates
            '  for all detected time zones.

            For Each adjustment As TimeZoneInfo.AdjustmentRule In adjustments

                '  Variable z.Id has the time zone ID. The outer For Each
                '  loop sets this value.

                timeZoneAdjustmentString += z.Id.ToString
                timeZoneAdjustmentString += "|"

                timeZoneAdjustmentString += timeZoneAdjustmentRuleNumber.ToString

                '   Increment ruleNumber for each detected adjustment rule

                timeZoneAdjustmentRuleNumber += 1

                timeZoneAdjustmentString += "|"
                timeZoneAdjustmentString += adjustment.DateStart.ToString
                timeZoneAdjustmentString += "|"
                timeZoneAdjustmentString += adjustment.DateEnd.ToString
                timeZoneAdjustmentString += "|"
                timeZoneAdjustmentString += adjustment.DaylightTransitionStart.IsFixedDateRule.ToString
                timeZoneAdjustmentString += "|"
                timeZoneAdjustmentString += adjustment.DaylightTransitionStart.Month.ToString
                timeZoneAdjustmentString += "|"
                timeZoneAdjustmentString += adjustment.DaylightTransitionStart.Day.ToString
                timeZoneAdjustmentString += "|"
                timeZoneAdjustmentString += adjustment.DaylightTransitionStart.Week.ToString
                timeZoneAdjustmentString += "|"
                timeZoneAdjustmentString += adjustment.DaylightTransitionStart.DayOfWeek.ToString
                timeZoneAdjustmentString += "|"
                timeZoneAdjustmentString += adjustment.DaylightTransitionStart.TimeOfDay.ToString
                timeZoneAdjustmentString += "|"
                timeZoneAdjustmentString += adjustment.DaylightTransitionEnd.IsFixedDateRule.ToString
                timeZoneAdjustmentString += "|"
                timeZoneAdjustmentString += adjustment.DaylightTransitionEnd.Month.ToString
                timeZoneAdjustmentString += "|"
                timeZoneAdjustmentString += adjustment.DaylightTransitionEnd.Day.ToString
                timeZoneAdjustmentString += "|"
                timeZoneAdjustmentString += adjustment.DaylightTransitionEnd.Week.ToString
                timeZoneAdjustmentString += "|"
                timeZoneAdjustmentString += adjustment.DaylightTransitionEnd.DayOfWeek.ToString
                timeZoneAdjustmentString += "|"
                timeZoneAdjustmentString += adjustment.DaylightTransitionEnd.TimeOfDay.ToString
                timeZoneAdjustmentString += "|"
                timeZoneAdjustmentString += adjustment.DaylightDelta.TotalSeconds.ToString
                timeZoneAdjustmentString += Environment.NewLine
            Next
        Next

        '   Remove the ending Environment.Newline characters

        timeZoneAdjustmentString = Microsoft.VisualBasic.Left(timeZoneAdjustmentString, (timeZoneAdjustmentString.Length - 2))
        timeZoneString = Microsoft.VisualBasic.Left(timeZoneString, (timeZoneString.Length - 2))

        richtxtbox_timezoneinfo.Text = timeZoneString
        Clipboard.SetText(richtxtbox_timezoneinfo.Text)

        richtxtbox_timezoneadjustmentinfo.Text = timeZoneAdjustmentString
        Clipboard.SetText(richtxtbox_timezoneadjustmentinfo.Text)

    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btn_exit.Click
        Me.Close()
    End Sub
End Class