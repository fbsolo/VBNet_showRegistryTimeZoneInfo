﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_exit = New System.Windows.Forms.Button()
        Me.richtxtbox_timezoneinfo = New System.Windows.Forms.RichTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.richtxtbox_timezoneadjustmentinfo = New System.Windows.Forms.RichTextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btn_exit
        '
        Me.btn_exit.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold)
        Me.btn_exit.Location = New System.Drawing.Point(448, 643)
        Me.btn_exit.Margin = New System.Windows.Forms.Padding(2)
        Me.btn_exit.Name = "btn_exit"
        Me.btn_exit.Size = New System.Drawing.Size(86, 31)
        Me.btn_exit.TabIndex = 1
        Me.btn_exit.Text = "E&xit"
        Me.btn_exit.UseVisualStyleBackColor = True
        '
        'richtxtbox_timezoneinfo
        '
        Me.richtxtbox_timezoneinfo.Location = New System.Drawing.Point(46, 11)
        Me.richtxtbox_timezoneinfo.Margin = New System.Windows.Forms.Padding(2)
        Me.richtxtbox_timezoneinfo.Name = "richtxtbox_timezoneinfo"
        Me.richtxtbox_timezoneinfo.Size = New System.Drawing.Size(891, 201)
        Me.richtxtbox_timezoneinfo.TabIndex = 3
        Me.richtxtbox_timezoneinfo.Text = ""
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Red
        Me.Label1.Location = New System.Drawing.Point(317, 510)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(349, 100)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Select the text to copy, then press" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Ctl-C" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "to place that text in the Windows" &
    " clipboard"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(436, 214)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(111, 16)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Time Zone Info"
        '
        'richtxtbox_timezoneadjustmentinfo
        '
        Me.richtxtbox_timezoneadjustmentinfo.Location = New System.Drawing.Point(46, 254)
        Me.richtxtbox_timezoneadjustmentinfo.Margin = New System.Windows.Forms.Padding(2)
        Me.richtxtbox_timezoneadjustmentinfo.Name = "richtxtbox_timezoneadjustmentinfo"
        Me.richtxtbox_timezoneadjustmentinfo.Size = New System.Drawing.Size(891, 201)
        Me.richtxtbox_timezoneadjustmentinfo.TabIndex = 6
        Me.richtxtbox_timezoneadjustmentinfo.Text = ""
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(396, 457)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(191, 16)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Time Zone Adjustment Info"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(982, 685)
        Me.ControlBox = False
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.richtxtbox_timezoneadjustmentinfo)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.richtxtbox_timezoneinfo)
        Me.Controls.Add(Me.btn_exit)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "Form1"
        Me.Text = "Time Zone Information From The Windows Registry"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn_exit As Button
    Friend WithEvents richtxtbox_timezoneinfo As RichTextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents richtxtbox_timezoneadjustmentinfo As RichTextBox
    Friend WithEvents Label3 As Label
End Class
