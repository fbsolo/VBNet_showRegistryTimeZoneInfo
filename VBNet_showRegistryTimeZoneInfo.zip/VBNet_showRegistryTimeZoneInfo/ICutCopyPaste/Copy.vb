﻿Namespace ICutCopyPaste
    Friend Class Copy
    End Class
End Namespace
